# Timing proof (fill in after a real submission is picked up by a scheduled run)

| Item | Value |
|---|---|
| Trainer Central email `Date` (UTC) | |
| Drive file name / id | |
| Scheduled run that posted it (log line time, UTC) | |
| Dashboard entry id | |
| Dashboard `created_at` (UTC) | |
| Elapsed (created_at - email Date) | must be < 1 hour |

Paste the matching `POSTED ...` line from logs/runs.log here:

```
```

Attach: screenshot of the entry on the dashboard, screenshot of the scheduled-task run history.
